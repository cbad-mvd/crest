Proudly created by myself.

This font has become more popular than I ever imagined. It's nice to have a font with such an "achievement". Thank you all for downloading. And for those who STILL keep e-mailing me about the legal use of this font - please stop. The only way you can support or "pay" me is to just download and use the font whenever and whereever you want. 
